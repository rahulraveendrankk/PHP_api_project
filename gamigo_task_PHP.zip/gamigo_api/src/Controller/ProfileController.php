<?php

namespace App\Controller;

use App\Entity\User;
use App\Repository\UserRepository;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class ProfileController extends AbstractController
{
    #[Route('/api/profile', name: 'app_profile', methods: 'post')]
    public function index(ManagerRegistry $doctrine,Request $request): Response
    {   
        $this->denyAccessUnlessGranted('IS_AUTHENTICATED_FULLY');
        $parameters= json_decode($request->getContent(), true);
        // print_r($parameters);die;
        $users=array();
        if(isset($parameters['email'])){
            $email=$parameters['email'];
            try{
                $users = $doctrine->getrepository(User::class)->findOneBy(['email'=>$email]);
                if(!empty($users))
                    $message='Success';
                else
                    $message='No data found';
            }catch(\Exception $e){

                // $message=$e->getMessage();
                $message='Api error';
            }
            
        }else{
            $message='Parameters missing';
        }
        return $this->json(array(
            'message'=>$message,
            'data'=>$users
        ));
    }

    #[Route('/api/profile/edit', name: 'app_profile_edit', methods: 'post')]
    public function edit(ManagerRegistry $doctrine,Request $request, UserRepository $use): Response
    {   
        $this->denyAccessUnlessGranted('IS_AUTHENTICATED_FULLY');
        $parameters= json_decode($request->getContent(), true);
         
        if(isset($parameters['email']) and isset($parameters['fullname']) and isset($parameters['address'])){
            try{ 
                $update = $use->updateByEmailField($parameters); 

                if($update==0)
                    $message='No data updated';
                else
                    $message='Your Profile data updated successfuly';
            }catch(\Exception $e){

                // $message=$e->getMessage();
                $message='Api error';
            }
        }else{
            $message='Parameters missing';
        }
         
        return $this->json(array(
            'message'=> $message
        ));
    }

    #[Route('/api/profile/delete', name: 'app_profile_delete', methods: 'post')]
    public function delete(ManagerRegistry $doctrine,Request $request, UserRepository $use): Response
    {   
        $this->denyAccessUnlessGranted('ROLE_ADMIN'); 
        $parameters= json_decode($request->getContent(), true);
         
        if(isset($parameters['email']) and isset($parameters['email_to_delete'])){

            try{ 
                $delete = $use->deleteByEmailField($parameters['email_to_delete']); 
                if($delete==0)
                    $message='Profile not exist';
                else
                    $message='Profile deleted successfuly';
            }catch(\Exception $e){

                // $message=$e->getMessage();
                $message='Api error';
            }
        }else{
            $message='Parameters missing';
        }
         
        return $this->json(array(
            'message'=> $message
        ));
    }

    #[Route('/api/profile/allUsers', name: 'app_profile_allUsers', methods: 'post')]
    public function allUsers(ManagerRegistry $doctrine,Request $request): Response
    {   
        $this->denyAccessUnlessGranted('ROLE_ADMIN'); 
        $parameters= json_decode($request->getContent(), true);
        // print_r($parameters);die;
        $users=array();
        if(isset($parameters['email'])){
            $email=$parameters['email'];
            try{
                $users = $doctrine->getrepository(User::class)->findAll();
                if(!empty($users))
                    $message='Success';
                else
                    $message='No data found';
            }catch(\Exception $e){ 
                // $message=$e->getMessage();
                $message='Api error';
            }
            
        }else{
            $message='Parameters missing';
        }
        return $this->json(array(
            'message'=>$message,
            'data'=>$users
        ));
    }

    
}
